#include <stdio.h>
#include <math.h>

int main()
{
	int Sum,SoNguyen, opA, opB, opC;
	printf("So nguyen 3 chu so la: ");
	scanf("%d", &SoNguyen);
	opA=SoNguyen/100;
	opB=(SoNguyen-(opA*100))/10;
	opC=SoNguyen-(opA*100)-(opB*10);
	Sum = opA + opB + opC;
	printf("Tong 3 chu so la: %d + %d + %d = %d", opA, opB, opC, Sum);
}
