#include <stdio.h>
#include <math.h>

int main(){
	int Nam, Tuoi, HienTai;
	HienTai = 2015;
	printf("Ban sinh nam bao nhieu: ");
	scanf("%d", &Nam);
	Tuoi = HienTai - Nam;
	printf("Ban sinh nam %d, vay ban %d tuoi", Nam, Tuoi);
	return 0;
}