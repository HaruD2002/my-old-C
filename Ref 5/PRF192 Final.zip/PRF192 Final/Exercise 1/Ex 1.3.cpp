#include <stdio.h>
#include <math.h>

int main()
{
	int r; 
	float Perimeter, Area;
	printf("Ban kinh hinh tron la: ");
	scanf("%d", &r);
	Perimeter = 2*3.14*r;
	Area = (r^2)*3.14;
	printf("\nChu vi hinh tron la: %.2f\n", Perimeter);
	printf("\nDien tich hinh tron la: %.2f", Area);
    return 0;
}