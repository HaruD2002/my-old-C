#include <stdio.h>

int main() {
	int n, sum = 1, count = 0;
	while (1) {
		printf (" Enter positive integer(Press 0 to quit): ");
		scanf("%d", &n);
		if (n==0) {
			break;
		} else if (n<0) {
			printf (" Incorect input, try again!\n");
		} else {
			for (int i=1; i<=n; i++){
				sum= sum + (2*i-1);
			}
			printf (" Sum: %d\n", sum);
		}
	}	
	return 0;
}
