#include <stdio.h>

int fun(int n){
	int count=0, a;
	for ( ;n!=0; ){
		a=n%10;
		n=n/10;
		if (a%2==1){
			count ++;
		}
	}
	return count;
}

int main(){
	int n;
	printf ("\n	Enter n: ");
	scanf ("%d", &n);
	printf ("\n	Amount odd number in number n: %d", fun(n));

	return 0;
}

