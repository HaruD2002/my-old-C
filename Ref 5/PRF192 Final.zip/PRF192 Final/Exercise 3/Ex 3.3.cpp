#include <stdio.h>

int main(){
	int n, sum = 0, count = 0;
	while (1){
		printf (" Enter an integer in [1-10](Press 0 to quit): ");
		scanf("%d", &n);
		if (n==0){
			break;
		}else if (n<0 || n>9){
			printf (" Incorect input, try again!\n");
		}
		else {
			sum+=n;
			count++;
		}
		
	}
	printf ("\n Number of integer entered: %d", count);
	printf ("\n Sum: %d", sum);
	return 0;
}

