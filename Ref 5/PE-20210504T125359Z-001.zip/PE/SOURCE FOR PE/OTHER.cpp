//THAYCACAC
#include <stdio.h>
//HAM TIM PHAN TU LON THU N TRONG MANG
void maxAdvance(int &n, int a[], int &x){
	int max1,maxn,min;
	printf("Enter n: ");
	scanf("%d",&n);
	for(int i=0; i<n; i++){
		printf("a[%d] = ",i);
		scanf("%d",&a[i]);
	}
	printf("Enter x: ");
	scanf("%d",&x);
	max1=a[0];
	for(int i=1;i<n;i++)
		if(a[i]>max1)	max1=a[i];
	min=a[0];
	for(int i=1;i<n;i++)
		if(a[i]<min)	min=a[i];
	if(x==1)	maxn=max1;
	if(x>1){
		for(int j=1;j<x;j++){
		maxn=min;
		for(int i=1;i<n;i++)
			if(a[i]>maxn&&a[i]<max1)	maxn=a[i];
		max1=maxn;
		}
	}
	printf("%d",maxn);
}

//HAM TIM UOC CHUNG LON NHAT
int gcd(int a, int b){
	while(a!=b){
		if(a>b)	a-=b;
		if(b>a) b-=a;
	}
	return a;
}
//HAM TIM BOI CHUNG NHO NHAT
int lcm(int a, int b){
	return (a*b/gcd(a,b));
}
//HAM DAO NGUOC SO
int swapNumber(int n){
	int temp;
	while(n!=0){
		temp=temp*10+n%10;
		n/=10;
	}
	printf("%d",temp);
}
//HAM CHUYEN SO SANG DANG NHI PHAN
int main(){
//	int n, a[100], x;	
//	maxAdvance(n,a,x);

//	int a, b;
//	scanf("%d %d",&a,&b);
//	printf("GCD: %d",gcd(a,b));
//	printf("LCM: %d",lcm(a,b));
	
	int n;
	scanf("%d",&n);
	swapNumber(n);
}


